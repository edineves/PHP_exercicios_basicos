<?php
    echo "2021 - Ano Atual - 50 anos <br>";

    for ($ano = 2020    ; $ano> 1971; $ano--) {
         echo "$ano <br>";
    }

    echo "1971 - Ano de nascimento";

?>
